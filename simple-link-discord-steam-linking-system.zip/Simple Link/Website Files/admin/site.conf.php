<?php
//MODIFY THESE//
    define("SiteName", "Rust Reborn");
    define("SiteDescription", "Rust Reborn Admin Panel");
    define("Domain", "RustReborn.link/admin");
?>